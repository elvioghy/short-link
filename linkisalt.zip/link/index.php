<!DOCTYPE html>
<html>
<head>
	<?php require_once 'sys/database.php'; ?>
	<title>élvio Technology | Link Kısaltma</title>
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
	<h1 lang="tr">Elvio Technology | Link Kısaltma Hizmetleri</h1><br>
	<form action="index.php" method="POST">
		<input type="url" name="link_url" placeholder="URL = (https://google.com.tr)" class="form-control">
		<br><br>
		<input type="submit" class="button" name="link" value="Link Kısalt">
	</form><br>
	<?php 

	if (isset($_POST['link'])) {
			$linkekle=$db->prepare("INSERT INTO link SET 
				link_url=:url
				");
			$linkinsert=$linkekle->execute(array(
				'url' => $_POST['link_url']
			));
			if ($linkinsert) {
				$linksor=$db->prepare("SELECT * FROM link WHERE link_url=:id");
				$linksor->execute(array('id'=> $_POST['link_url']));

				$linkcek=$linksor->fetch(PDO::FETCH_ASSOC);
				echo "<div class='cevap'><label class='green'>Link kısaltma başarılı! Link aşağıdadır:<br></label>
				<a target='_blank' href='".$_POST['link_url']."'>".$_POST['link_url']."</a> - <a target='_blank' href='index.php?id=".$linkcek['link_id']."'>Kısaltılmış Link</a></div>";
			} else {
				echo "<div class='cevap'><label class='red'>İşlem yapılamadı, link kısaltılamadı!</label></div>";
			}
	}
	if (isset($_GET['id'])) {
		$linksor=$db->prepare("SELECT * FROM link WHERE link_id=:id");
		$linksor->execute(array('id'=> $_GET['id']));

		$linkcek=$linksor->fetch(PDO::FETCH_ASSOC);
		echo "<div class='cevap'><h2 class='ozelh1'>3 saniye içerisinde yönlendirileceksiniz...</h2></div>";
		header("Refresh: 3; url=".$linkcek['link_url']);
	}
	?>
</body>
</html>