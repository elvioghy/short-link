<?php 
try {
	$host="mysql:host=localhost;dbname=link;charset=utf8";
	$dbuser="root";
	$dbpass="";
	$db=new PDO($host, $dbuser, $dbpass);
} catch (PDOExpception $e) {
	echo $e;
}

?>
